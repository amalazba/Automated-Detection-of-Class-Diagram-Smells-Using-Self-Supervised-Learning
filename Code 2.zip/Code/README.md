# Automated-Detection-of-Class-Diagram-Smells-Using-Self-Supervised-Learning

The source code is provided in this folder. This folder contains:

- MoRT.ipynb: This is a Python notebook that contains the whole source code.
- Keywords.txt: This is a helper file that is needed during running the code, it contains a set of keywords that are used to mask the source code. You don't need to change this file.
- cross-projects.csv: This is a helper file that is needed during running the code, it is used to perform the cross-evaluation, you need to change the project name based on your data.


To run the MoRT.ipynb file you need to install the following:
- An IDE for running Python notebooks such as Jupyter in Anaconda. 
- Install the required packages (Tensorflow, SMOTE, .. etc) using Pip install command.
- It's better to have a GPU.

To use the code you only need to run each cell one by one, the cells have headings & subheadings, and the functions are organized based on them to easily identify the function responsible for each step. Here are some of the main headings: 
- Working directory set-up: this is important to help you set up the working directory where you have your data. Also, it makes sure that Tensorflow can actually see and use you GPU. 
- Imports: it imports all required library, if an error accure then use "pip" command to install the library.
- The restt of the code are seperated into functions that will be used in the main, run all cells.
- In the "Main" section make sure to change values of the parameters based on your need, like the dataset path and the model name (Transformer, LSTM, CNN, ANN ..)